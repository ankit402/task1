﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

namespace WebApplication1
{
    public class RacksController : Controller
    {
        private readonly Task1Context _context;

        public RacksController(Task1Context context)
        {
            _context = context;
        }

        // GET: Racks
        public async Task<IActionResult> Index()
        {
              return _context.Racks != null ? 
                          View(await _context.Racks.ToListAsync()) :
                          Problem("Entity set 'Task1Context.Racks'  is null.");
        }

        // GET: Racks/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Racks == null)
            {
                return NotFound();
            }

            var rack = await _context.Racks
                .FirstOrDefaultAsync(m => m.RackId == id);
            if (rack == null)
            {
                return NotFound();
            }

            return View(rack);
        }

        // GET: Racks/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Racks/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Code")] Rack rack)
        {
            //if (ModelState.IsValid)
            {
                _context.Add(rack);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(rack);
        }

        // GET: Racks/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Racks == null)
            {
                return NotFound();
            }

            var rack = await _context.Racks.FindAsync(id);
            if (rack == null)
            {
                return NotFound();
            }
            return View(rack);
        }

        // POST: Racks/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Code,RackId")] Rack rack)
        {
            if (id != rack.RackId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(rack);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RackExists(rack.RackId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(rack);
        }

        // GET: Racks/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Racks == null)
            {
                return NotFound();
            }

            var rack = await _context.Racks
                .FirstOrDefaultAsync(m => m.RackId == id);
            if (rack == null)
            {
                return NotFound();
            }

            return View(rack);
        }

        // POST: Racks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Racks == null)
            {
                return Problem("Entity set 'Task1Context.Racks'  is null.");
            }
            var rack = await _context.Racks.FindAsync(id);
            if (rack != null)
            {
                _context.Racks.Remove(rack);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool RackExists(int id)
        {
          return (_context.Racks?.Any(e => e.RackId == id)).GetValueOrDefault();
        }
    }
}
