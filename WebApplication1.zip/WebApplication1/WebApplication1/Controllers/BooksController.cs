﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using NuGet.Protocol;
using WebApplication1.Models;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Newtonsoft.Json;
using iTextSharp.text.pdf.qrcode;
using static Org.BouncyCastle.Math.EC.ECCurve;
using System.Data.SqlClient;
using static System.Reflection.Metadata.BlobBuilder;

namespace WebApplication1
{
    public class BooksController : Controller
    {
        private readonly Task1Context _context;
        string connectionString = string.Empty;
        public BooksController(Task1Context context)
        {
            _context = context;
            connectionString = _context.Database.GetConnectionString();
        }

        // GET: Books
        public async Task<IActionResult> Index()
        {
            try
            {
                if (ModelState.IsValid)
                {
                    //List<Book> list;
                    //list = _context.Books.FromSqlRaw<Book>("EXEC GetAllBookslist").ToList();
                    //return View(list.ToList());
                    var libraryDbContext = _context.Books.Include(b => b.Shelf).Include(C => C.Rack).Where(k => k.Flag == true);
                    return View(await libraryDbContext.ToListAsync());
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                //throw;
            }
            return View();

        }

        // GET: Books/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Books == null)
            {
                return NotFound();
            }

            var book = await _context.Books
                .Include(b => b.Rack)
                .Include(b => b.Shelf)
                .FirstOrDefaultAsync(m => m.Code == id);
            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // GET: Books/Create
        public IActionResult Create()
        {
            ViewData["RackId"] = new SelectList(_context.Racks, "RackId", "RackId");
            ViewData["ShelfId"] = new SelectList(_context.Shelves, "ShelfId", "ShelfId");
            return View();
        }

        // POST: Books/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Code,Name,Author,IsAvailable,Price,RackId,ShelfId")] Book books)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using SqlConnection connection = new SqlConnection(connectionString);
                    await connection.OpenAsync();
                    using SqlCommand command = new SqlCommand("InsertNewBookDetails", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Code", books.Code);
                    command.Parameters.AddWithValue("@Name", books.Name);
                    command.Parameters.AddWithValue("@Author", books.Author);
                    command.Parameters.AddWithValue("@IsAvailable", books.IsAvailable);
                    command.Parameters.AddWithValue("@Price", books.Price);
                    command.Parameters.AddWithValue("@RackID", books.RackId);
                    command.Parameters.AddWithValue("@ShelfID", books.ShelfId);
                    await command.ExecuteNonQueryAsync();
                    await connection.CloseAsync();
                    TempData["success"] = "Book Created successfully";
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                //throw;
            }

            return RedirectToAction("Index");
        }
        // GET: Books/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Books == null)
            {
                return NotFound();
            }

            var book = await _context.Books.FindAsync(id);
            if (book == null)
            {
                return NotFound();
            }
            ViewData["RackId"] = new SelectList(_context.Racks, "RackId", "RackId", book.RackId);
            ViewData["ShelfId"] = new SelectList(_context.Shelves, "ShelfId", "ShelfId", book.ShelfId);

            return View(book);
        }

        // POST: Books/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Code,Name,Author,IsAvailable,Price,RackId,ShelfId")] Book books)
        {
            if (id != books.Code)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    //_context.Update(book);
                    using SqlConnection connection = new SqlConnection(connectionString);
                    await connection.OpenAsync();
                    using SqlCommand command = new SqlCommand("UpdateBookDetails", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@BookID", id);
                    command.Parameters.AddWithValue("@Name", books.Name);
                    command.Parameters.AddWithValue("@Author", books.Author);
                    command.Parameters.AddWithValue("@IsAvailable", books.IsAvailable);
                    command.Parameters.AddWithValue("@Price", books.Price);
                    command.Parameters.AddWithValue("@RackID", books.RackId);
                    command.Parameters.AddWithValue("@ShelfID", books.ShelfId);
                    await command.ExecuteNonQueryAsync();
                    await connection.CloseAsync();
                    TempData["success"] = "Book Updated successfully";
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookExists(books.Code))
                    {
                        TempData["error"] = "Book Updated Failed";
                        return NotFound();
                    }
                    else
                    {
                       // throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["RackId"] = new SelectList(_context.Racks, "RackId", "RackId", books.RackId);
            ViewData["ShelfId"] = new SelectList(_context.Shelves, "ShelfId", "ShelfId", books.ShelfId);
            return View(books);
        }

        // GET: Books/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Books == null)
            {
                return NotFound();
            }

            var book = await _context.Books
                .Include(b => b.Rack)
                .Include(b => b.Shelf)
                .FirstOrDefaultAsync(m => m.Code == id);
            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // POST: Books/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Books == null)
            {
                return Problem("Entity set 'Task1Context.Books'  is null.");
            }
            var books = await _context.Books.FindAsync(id);
            if (books != null)
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                await connection.OpenAsync();
                using SqlCommand command = new SqlCommand("DeleteBook", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Code", id);
                await command.ExecuteNonQueryAsync();
                await connection.CloseAsync();
                TempData["success"] = "Book Delete successfully";
                await _context.SaveChangesAsync();


               // _context.Books.Remove(book);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BookExists(int id)
        {
            return (_context.Books?.Any(e => e.Code == id)).GetValueOrDefault();
        }
    }
}
