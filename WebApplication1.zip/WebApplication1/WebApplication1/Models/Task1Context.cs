﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models;

public partial class Task1Context : DbContext
{
    public Task1Context()
    {
    }

    public Task1Context(DbContextOptions<Task1Context> options)
        : base(options)
    {
    }

    public virtual DbSet<Book> Books { get; set; }

    public virtual DbSet<Rack> Racks { get; set; }

    public virtual DbSet<Shelf> Shelves { get; set; }

    //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    //    => optionsBuilder.UseSqlServer("Server=DESKTOP-77MGK46;Database=Task1;Trusted_Connection=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Book>(entity =>
        {
            entity.HasKey(e => e.Code).HasName("PK__Book__A25C5AA6704D020B");

            entity.ToTable("Book");

            entity.Property(e => e.Code).ValueGeneratedNever();
            entity.Property(e => e.Author)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.Name)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.Price).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.RackId).HasColumnName("RackID");
            entity.Property(e => e.ShelfId).HasColumnName("ShelfID");

            entity.HasOne(d => d.Rack).WithMany(p => p.Books)
                .HasForeignKey(d => d.RackId)
                .HasConstraintName("FK_Book_Racks");

            entity.HasOne(d => d.Shelf).WithMany(p => p.Books)
                .HasForeignKey(d => d.ShelfId)
                .HasConstraintName("FK_Book_Shelves");
        });

        modelBuilder.Entity<Rack>(entity =>
        {
            entity.HasKey(e => e.RackId).HasName("PK__Racks__0363D948DE9BF897");

            //entity.Property(e => e.RackId)
            //    .ValueGeneratedNever()
            //    .HasColumnName("RackID");
        });

        modelBuilder.Entity<Shelf>(entity =>
        {
            entity.HasKey(e => e.ShelfId).HasName("PK__Shelves__DBD04F278BB3F694");

            //entity.Property(e => e.ShelfId)
            //    .ValueGeneratedNever()
            //    .HasColumnName("ShelfID");
            entity.Property(e => e.RackId).HasColumnName("RackID");

            entity.HasOne(d => d.Rack).WithMany(p => p.Shelves)
                .HasForeignKey(d => d.RackId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Shelves_Racks");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
