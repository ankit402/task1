﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models;

public partial class Book
{
   
    public int Code { get; set; }

    public string? Name { get; set; }

    public string? Author { get; set; }

    public bool? IsAvailable { get; set; }

    public bool? Flag { get; set; }

    public decimal? Price { get; set; }

    public int? RackId { get; set; }

    public int? ShelfId { get; set; }

    public virtual Rack? Rack { get; set; }

    public virtual Shelf? Shelf { get; set; }
}
