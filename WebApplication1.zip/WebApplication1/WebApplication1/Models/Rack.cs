﻿using MessagePack;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models;

public partial class Rack
{
    [System.ComponentModel.DataAnnotations.Key]
    public int RackId { get; set; }

    public string Code { get; set; }

    public virtual ICollection<Book> Books { get; set; } = new List<Book>();

    public virtual ICollection<Shelf> Shelves { get; set; } = new List<Shelf>();
}
